# Ascend (native Android, Kotlin + Jetpack Compose)

No WebView. Everything is native Compose.

## Build the APK on GitHub
1. Create a new empty GitHub repository.
2. Upload ALL files from this folder (keep `.github/workflows/build.yml` in place), commit to `main`.
3. Open the repo -> Actions -> "Build APK" (it also runs on every push; use "Run workflow" to start it by hand).
4. When it is green, open the run -> Artifacts -> download `Ascend-debug-apk`, unzip, install `app-debug.apk`.
