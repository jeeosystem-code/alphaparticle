package com.ascend.app.ui

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Click without a ripple, like the web app's flat buttons. */
fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    clickable(
        enabled = enabled,
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}

@Composable
fun Hero(first: String, second: String, modifier: Modifier = Modifier) {
    val c = A.c
    Text(
        text = buildAnnotatedString {
            append(first)
            append("\n")
            withStyle(SpanStyle(color = c.sand, fontStyle = FontStyle.Italic)) { append(second) }
        },
        fontSize = 50.sp,
        lineHeight = 52.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-1.5).sp,
        color = c.ink,
        modifier = modifier
    )
}

@Composable
fun Lead(text: String, modifier: Modifier = Modifier) {
    Text(
        text, fontSize = 16.sp, lineHeight = 22.sp, color = A.c.muted,
        modifier = modifier.padding(top = 12.dp, bottom = 18.dp)
    )
}

@Composable
fun QLabel(text: String, modifier: Modifier = Modifier, color: Color = A.c.muted) {
    Text(
        text.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.1.sp, color = color, modifier = modifier
    )
}

@Composable
fun PillButton(
    text: String,
    modifier: Modifier = Modifier,
    bg: Color = A.c.btn,
    fg: Color = A.c.btnT,
    shadow: Color = A.c.btn.copy(alpha = 0.45f),
    border: Color? = null,
    fontSp: Int = 18,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val off by animateDpAsState(if (pressed) 4.dp else 0.dp, label = "pill")
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .drawBehind {
                val o = 6.dp.toPx()
                drawRoundRect(
                    color = shadow,
                    topLeft = Offset(0f, o),
                    size = Size(size.width, size.height - o),
                    cornerRadius = CornerRadius((size.height - o) / 2f)
                )
            }
            .padding(bottom = 6.dp)
    ) {
        Box(
            Modifier
                .offset(y = off)
                .fillMaxWidth()
                .clip(shape)
                .background(bg)
                .then(if (border != null) Modifier.border(2.dp, border, shape) else Modifier)
                .clickable(enabled = enabled, interactionSource = src, indication = null, onClick = onClick)
                .padding(vertical = 17.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = fg, fontSize = fontSp.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp, maxLines = 1)
        }
    }
}

@Composable
fun Card3D(
    modifier: Modifier = Modifier,
    radius: Dp = 26.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = A.c
    val shape = RoundedCornerShape(radius)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val off by animateDpAsState(if (pressed) 4.dp else 0.dp, label = "card")
    Box(
        modifier
            .drawBehind {
                val o = 6.dp.toPx()
                drawRoundRect(
                    color = c.ink.copy(alpha = 0.10f),
                    topLeft = Offset(0f, o),
                    size = Size(size.width, size.height - o),
                    cornerRadius = CornerRadius(radius.toPx())
                )
            }
            .padding(bottom = 6.dp)
    ) {
        Column(
            Modifier
                .offset(y = off)
                .fillMaxWidth()
                .clip(shape)
                .background(c.card)
                .border(1.5.dp, c.line, shape)
                .then(
                    if (onClick != null) Modifier.clickable(interactionSource = src, indication = null, onClick = onClick)
                    else Modifier
                )
                .padding(18.dp),
            content = content
        )
    }
}

@Composable
fun FlatCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = A.c
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(1.5.dp, c.line, shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun InputBox(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    number: Boolean = false,
    decimal: Boolean = false,
    big: Boolean = true,
    maxLen: Int = 60,
    onDone: (() -> Unit)? = null
) {
    val c = A.c
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(18.dp)
    val fs = if (big) 28.sp else 22.sp
    val fw = if (big) FontWeight.Bold else FontWeight.SemiBold
    Column(
        modifier
            .clip(shape)
            .background(c.card)
            .border(1.5.dp, if (focused) c.sand else c.line, shape)
            .padding(start = 14.dp, end = 14.dp, top = 9.dp, bottom = 8.dp)
    ) {
        Text(label.uppercase(), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = c.muted)
        Box(Modifier.fillMaxWidth()) {
            if (value.isEmpty() && placeholder.isNotEmpty()) {
                Text(placeholder, fontSize = fs, fontWeight = fw, color = c.muted.copy(alpha = 0.45f), maxLines = 1)
            }
            BasicTextField(
                value = value,
                onValueChange = { if (it.length <= maxLen) onChange(it) },
                singleLine = true,
                textStyle = TextStyle(fontSize = fs, fontWeight = fw, color = c.ink),
                cursorBrush = SolidColor(c.sand),
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (decimal) KeyboardType.Decimal else if (number) KeyboardType.Number else KeyboardType.Text,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { focused = it.isFocused }
            )
        }
    }
}

@Composable
fun TopBar(back: String, onBack: () -> Unit, right: @Composable RowScope.() -> Unit = {}) {
    val c = A.c
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .tap(onClick = onBack)
                .padding(vertical = 8.dp, horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ChevronBack(c.muted)
            QLabel(back)
        }
        Box(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically, content = right)
    }
}

@Composable
fun RoundBtn(onClick: () -> Unit, content: @Composable () -> Unit) {
    val c = A.c
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(c.card)
            .border(1.5.dp, c.line, CircleShape)
            .tap(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun ThemeToggle(dark: Boolean, onClick: () -> Unit) {
    val c = A.c
    RoundBtn(onClick) {
        Canvas(Modifier.size(18.dp)) {
            val sw = 1.8.dp.toPx()
            val cx = size.width / 2f
            val cy = size.height / 2f
            if (!dark) {
                drawCircle(c.ink, radius = size.width * 0.22f, center = Offset(cx, cy), style = Stroke(sw))
                for (i in 0 until 8) {
                    val a = i * Math.PI / 4.0
                    val r1 = size.width * 0.34f
                    val r2 = size.width * 0.46f
                    drawLine(
                        c.ink,
                        Offset(cx + (Math.cos(a) * r1).toFloat(), cy + (Math.sin(a) * r1).toFloat()),
                        Offset(cx + (Math.cos(a) * r2).toFloat(), cy + (Math.sin(a) * r2).toFloat()),
                        strokeWidth = sw, cap = StrokeCap.Round
                    )
                }
            } else {
                drawCircle(c.ink, radius = size.width * 0.38f, center = Offset(cx, cy))
                drawCircle(c.card, radius = size.width * 0.34f, center = Offset(cx + size.width * 0.2f, cy - size.width * 0.14f))
            }
        }
    }
}

@Composable
fun ProfileIcon(onClick: () -> Unit) {
    val c = A.c
    RoundBtn(onClick) {
        Canvas(Modifier.size(18.dp)) {
            val sw = 1.8.dp.toPx()
            drawCircle(c.ink, radius = size.width * 0.17f, center = Offset(size.width / 2f, size.height * 0.34f), style = Stroke(sw))
            val p = Path()
            p.moveTo(size.width * 0.18f, size.height * 0.88f)
            p.cubicTo(size.width * 0.22f, size.height * 0.66f, size.width * 0.36f, size.height * 0.6f, size.width * 0.5f, size.height * 0.6f)
            p.cubicTo(size.width * 0.64f, size.height * 0.6f, size.width * 0.78f, size.height * 0.66f, size.width * 0.82f, size.height * 0.88f)
            drawPath(p, c.ink, style = Stroke(sw, cap = StrokeCap.Round))
        }
    }
}

@Composable
fun ChevronBack(color: Color, modifier: Modifier = Modifier.size(12.dp)) {
    Canvas(modifier) {
        val p = Path()
        p.moveTo(size.width * 0.67f, size.height * 0.08f)
        p.lineTo(size.width * 0.25f, size.height * 0.5f)
        p.lineTo(size.width * 0.67f, size.height * 0.92f)
        drawPath(p, color, style = Stroke(2.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun ChevronRight(color: Color, modifier: Modifier = Modifier.size(12.dp)) {
    Canvas(modifier) {
        val p = Path()
        p.moveTo(size.width * 0.33f, size.height * 0.08f)
        p.lineTo(size.width * 0.75f, size.height * 0.5f)
        p.lineTo(size.width * 0.33f, size.height * 0.92f)
        drawPath(p, color, style = Stroke(2.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun PlusIcon(color: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val sw = 2.4.dp.toPx()
        drawLine(color, Offset(size.width / 2f, size.height * 0.2f), Offset(size.width / 2f, size.height * 0.8f), sw, StrokeCap.Round)
        drawLine(color, Offset(size.width * 0.2f, size.height / 2f), Offset(size.width * 0.8f, size.height / 2f), sw, StrokeCap.Round)
    }
}

@Composable
fun PlayIcon(color: Color, modifier: Modifier = Modifier.size(18.dp)) {
    Canvas(modifier) {
        val p = Path()
        p.moveTo(size.width * 0.33f, size.height * 0.23f)
        p.lineTo(size.width * 0.33f, size.height * 0.77f)
        p.lineTo(size.width * 0.79f, size.height * 0.5f)
        p.close()
        drawPath(p, color)
    }
}

@Composable
fun FabPlus(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = A.c
    Box(
        modifier
            .size(58.dp)
            .clip(CircleShape)
            .background(c.btn)
            .tap(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { PlusIcon(c.btnT) }
}

/** Soft "glass" tile icon, an approximation of the web app's gradient SVG icons. */
@Composable
fun GlassIcon(color: Color, kind: Int, modifier: Modifier = Modifier.size(52.dp)) {
    val c = A.c
    Canvas(modifier) {
        val w = size.width
        val accent = Brush.linearGradient(listOf(color.copy(alpha = 0.55f), color))
        when (kind % 4) {
            0 -> {
                drawCircle(accent, radius = w * 0.26f, center = Offset(w * 0.72f, w * 0.3f))
                drawRoundRect(
                    color = c.card.copy(alpha = 0.85f), topLeft = Offset(w * 0.08f, w * 0.34f),
                    size = Size(w * 0.62f, w * 0.58f), cornerRadius = CornerRadius(w * 0.2f)
                )
                drawRoundRect(
                    color = color, topLeft = Offset(w * 0.08f, w * 0.34f), size = Size(w * 0.62f, w * 0.58f),
                    cornerRadius = CornerRadius(w * 0.2f), style = Stroke(1.6.dp.toPx())
                )
            }
            1 -> {
                drawRoundRect(accent, Offset(w * 0.46f, w * 0.1f), Size(w * 0.44f, w * 0.64f), CornerRadius(w * 0.18f))
                drawRoundRect(
                    color = c.card.copy(alpha = 0.85f), topLeft = Offset(w * 0.1f, w * 0.26f),
                    size = Size(w * 0.5f, w * 0.64f), cornerRadius = CornerRadius(w * 0.18f)
                )
                drawRoundRect(
                    color = color, topLeft = Offset(w * 0.1f, w * 0.26f), size = Size(w * 0.5f, w * 0.64f),
                    cornerRadius = CornerRadius(w * 0.18f), style = Stroke(1.6.dp.toPx())
                )
            }
            2 -> {
                drawCircle(accent, radius = w * 0.22f, center = Offset(w * 0.7f, w * 0.7f))
                drawCircle(color = c.card.copy(alpha = 0.85f), radius = w * 0.32f, center = Offset(w * 0.42f, w * 0.44f))
                drawCircle(color = color, radius = w * 0.32f, center = Offset(w * 0.42f, w * 0.44f), style = Stroke(1.6.dp.toPx()))
            }
            else -> {
                drawRoundRect(accent, Offset(w * 0.5f, w * 0.5f), Size(w * 0.4f, w * 0.4f), CornerRadius(w * 0.14f))
                drawRoundRect(
                    color = c.card.copy(alpha = 0.85f), topLeft = Offset(w * 0.1f, w * 0.1f),
                    size = Size(w * 0.58f, w * 0.58f), cornerRadius = CornerRadius(w * 0.2f)
                )
                drawRoundRect(
                    color = color, topLeft = Offset(w * 0.1f, w * 0.1f), size = Size(w * 0.58f, w * 0.58f),
                    cornerRadius = CornerRadius(w * 0.2f), style = Stroke(1.6.dp.toPx())
                )
            }
        }
    }
}

@Composable
fun Tile(
    title: String,
    caption: String,
    color: Color,
    kind: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val c = A.c
    Card3D(modifier, onClick = onClick) {
        GlassIcon(color, kind)
        Text(
            title, fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp,
            color = c.ink, modifier = Modifier.padding(top = 10.dp)
        )
        Text(caption, fontSize = 13.5.sp, color = c.muted, modifier = Modifier.padding(top = 2.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val c = A.c
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(1.5.dp, c.line, shape)
            .padding(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .clip(shape)
                    .background(if (on) c.btn else Color.Transparent)
                    .tap { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold,
                    color = if (on) c.btnT else c.muted, maxLines = 1
                )
            }
        }
    }
}

@Composable
fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val c = A.c
    val off by animateDpAsState(if (on) 20.dp else 0.dp, label = "tg")
    Box(
        Modifier
            .width(48.dp)
            .height(28.dp)
            .clip(RoundedCornerShape(50))
            .background(if (on) c.good else c.line)
            .tap { onChange(!on) }
            .padding(3.dp)
    ) {
        Box(
            Modifier
                .offset(x = off)
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

@Composable
fun StepperRow(title: String, subtitle: String, value: Int, onChange: (Int) -> Unit, min: Int = 1, max: Int = 180) {
    val c = A.c
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c.ink)
            Text(subtitle, fontSize = 12.5.sp, color = c.muted)
        }
        StepBtn("−") { if (value > min) onChange(value - 1) }
        Text(
            value.toString(), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = c.ink,
            modifier = Modifier.width(46.dp), textAlign = TextAlign.Center
        )
        StepBtn("+") { if (value < max) onChange(value + 1) }
    }
}

@Composable
fun StepBtn(label: String, onClick: () -> Unit) {
    val c = A.c
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(c.card)
            .border(1.5.dp, c.line, CircleShape)
            .tap(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = c.ink) }
}

@Composable
fun Chip(text: String, on: Boolean, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = A.c
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(if (on) color.copy(alpha = 0.16f) else Color.Transparent)
            .border(1.5.dp, if (on) color else c.line, shape)
            .tap(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (on) color else c.muted, maxLines = 1)
    }
}

@Composable
fun SectionLabel(text: String) {
    QLabel(text, Modifier.padding(top = 22.dp, bottom = 8.dp))
}

@Composable
fun SettingRow(text: String, danger: Boolean = false, onClick: () -> Unit) {
    val c = A.c
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(shape)
            .background(c.card)
            .border(1.5.dp, c.line, shape)
            .tap(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = if (danger) c.bad else c.ink)
        ChevronRight(c.muted)
    }
}
