package com.ascend.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** One question in a practice session. st: "A" attempted, "N" not attempted, null = unanswered. */
data class QRes(
    val no: Int,
    val st: String? = null,
    val t: Long = 0L,
    val w: Boolean = false,
    val d: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("no", no).put("st", st ?: "").put("t", t).put("w", w).put("d", d)

    companion object {
        fun fromJson(o: JSONObject): QRes {
            val s = o.optString("st", "")
            return QRes(o.optInt("no"), if (s.isEmpty()) null else s, o.optLong("t"), o.optBoolean("w"), o.optBoolean("d"))
        }
    }
}

data class SessionRec(
    val id: String,
    val name: String,
    val date: Long,
    val from: Int,
    val to: Int,
    val pos: Double,
    val neg: Double,
    val res: List<QRes>,
    val hw: String? = null
) {
    fun marks(r: QRes): Double = if (r.st != "A") 0.0 else if (r.w) -neg else pos
    val max: Double get() = res.size * pos
    val score: Double get() = res.sumOf { marks(it) }
    val att: Int get() = res.count { it.st == "A" }
    val skipped: Int get() = res.count { it.st == "N" }
    val unanswered: Int get() = res.count { it.st == null }
    val wrong: Int get() = res.count { it.st == "A" && it.w }
    val correct: Int get() = att - wrong
    val totalMs: Long get() = res.sumOf { it.t }
    val visited: Int get() = att + skipped
    val avgMs: Long
        get() {
            val v = res.filter { it.st != null }
            return if (v.isEmpty()) 0L else v.sumOf { it.t } / v.size
        }
    val fastest: QRes? get() = res.filter { it.st != null }.minByOrNull { it.t }
    val slowest: QRes? get() = res.filter { it.st != null }.maxByOrNull { it.t }

    fun toJson(): JSONObject {
        val a = JSONArray()
        res.forEach { a.put(it.toJson()) }
        return JSONObject().put("id", id).put("name", name).put("date", date)
            .put("from", from).put("to", to).put("pos", pos).put("neg", neg)
            .put("hw", hw ?: "").put("res", a)
    }

    companion object {
        fun fromJson(o: JSONObject): SessionRec {
            val a = o.optJSONArray("res") ?: JSONArray()
            val list = ArrayList<QRes>()
            for (i in 0 until a.length()) list.add(QRes.fromJson(a.getJSONObject(i)))
            val h = o.optString("hw", "")
            return SessionRec(
                o.optString("id"), o.optString("name"), o.optLong("date"),
                o.optInt("from"), o.optInt("to"), o.optDouble("pos", 4.0), o.optDouble("neg", 1.0),
                list, if (h.isEmpty()) null else h
            )
        }
    }
}

/** An unfinished practice session that can be resumed. */
data class Draft(
    val name: String,
    val from: Int,
    val to: Int,
    val pos: Double,
    val neg: Double,
    val hw: String?,
    val res: List<QRes>,
    val idx: Int
) {
    val answered: Int get() = res.count { it.st != null }

    fun toJson(): JSONObject {
        val a = JSONArray()
        res.forEach { a.put(it.toJson()) }
        return JSONObject().put("name", name).put("from", from).put("to", to)
            .put("pos", pos).put("neg", neg).put("hw", hw ?: "").put("idx", idx).put("res", a)
    }

    companion object {
        fun fromJson(o: JSONObject): Draft {
            val a = o.optJSONArray("res") ?: JSONArray()
            val list = ArrayList<QRes>()
            for (i in 0 until a.length()) list.add(QRes.fromJson(a.getJSONObject(i)))
            val h = o.optString("hw", "")
            return Draft(
                o.optString("name"), o.optInt("from"), o.optInt("to"),
                o.optDouble("pos", 4.0), o.optDouble("neg", 1.0),
                if (h.isEmpty()) null else h, list, o.optInt("idx")
            )
        }
    }
}

data class HwSubject(val id: String, val name: String, val color: Int) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("color", color)

    companion object {
        fun fromJson(o: JSONObject) = HwSubject(o.optString("id"), o.optString("name"), o.optInt("color"))
    }
}

data class HwItem(
    val id: String,
    val subjectId: String,
    val title: String,
    val date: String,          // yyyy-MM-dd
    val priority: Int,         // 0 none, 1 high, 2 medium, 3 low
    val from: Int,             // 0 = no question range
    val to: Int,
    val note: String,
    val done: Boolean,
    val attempted: List<Int>
) {
    val hasRange: Boolean get() = from >= 1 && to >= from
    val numbers: List<Int> get() = if (hasRange) (from..to).toList() else emptyList()
    val left: List<Int> get() = numbers.filter { it !in attempted }
    val progress: Float
        get() = if (!hasRange) (if (done) 1f else 0f)
        else (numbers.size - left.size).toFloat() / numbers.size

    fun toJson(): JSONObject {
        val a = JSONArray()
        attempted.forEach { a.put(it) }
        return JSONObject().put("id", id).put("s", subjectId).put("title", title).put("date", date)
            .put("pr", priority).put("from", from).put("to", to).put("note", note)
            .put("done", done).put("at", a)
    }

    companion object {
        fun fromJson(o: JSONObject): HwItem {
            val a = o.optJSONArray("at") ?: JSONArray()
            val l = ArrayList<Int>()
            for (i in 0 until a.length()) l.add(a.getInt(i))
            return HwItem(
                o.optString("id"), o.optString("s"), o.optString("title"), o.optString("date"),
                o.optInt("pr"), o.optInt("from"), o.optInt("to"), o.optString("note"),
                o.optBoolean("done"), l
            )
        }
    }
}

// ---------- formatting helpers (same output as the web app) ----------

fun fmtMs(ms: Long): String {
    val s0 = Math.round(ms / 1000.0)
    val h = s0 / 3600
    val m = (s0 % 3600) / 60
    val s = s0 % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}

fun numStr(x: Double): String {
    val r = Math.round(x * 100) / 100.0
    return if (r == Math.floor(r)) r.toLong().toString() else r.toString()
}

fun newId(): String = java.lang.Long.toString(System.currentTimeMillis(), 36) +
    java.lang.Integer.toString((Math.random() * 1679616).toInt(), 36)
