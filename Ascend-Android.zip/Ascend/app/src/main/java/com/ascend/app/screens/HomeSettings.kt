package com.ascend.app.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.AppVm
import com.ascend.app.Screen
import com.ascend.app.ui.A
import com.ascend.app.ui.Card3D
import com.ascend.app.ui.Hero
import com.ascend.app.ui.InputBox
import com.ascend.app.ui.Lead
import com.ascend.app.ui.PillButton
import com.ascend.app.ui.PlayIcon
import com.ascend.app.ui.PlusIcon
import com.ascend.app.ui.ProfileIcon
import com.ascend.app.ui.QLabel
import com.ascend.app.ui.SectionLabel
import com.ascend.app.ui.Segmented
import com.ascend.app.ui.SettingRow
import com.ascend.app.ui.ThemeToggle
import com.ascend.app.ui.Tile
import com.ascend.app.ui.Toggle
import com.ascend.app.ui.TopBar
import com.ascend.app.ui.tap
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(vm: AppVm, dark: Boolean, onToggleTheme: () -> Unit) {
    val c = A.c
    val store = vm.store
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greet = if (hour < 12) "morning." else if (hour < 17) "afternoon." else "evening."
    val dateText = SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(Date())
    val name = store.userName

    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Canvas(Modifier.size(30.dp)) {
                drawRoundRect(
                    brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF4AA3FF), Color(0xFF5E5CE6))),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.width * 0.28f)
                )
                val p = androidx.compose.ui.graphics.Path()
                p.moveTo(size.width * 0.23f, size.height * 0.7f)
                p.lineTo(size.width * 0.4f, size.height * 0.53f)
                p.lineTo(size.width * 0.5f, size.height * 0.63f)
                p.lineTo(size.width * 0.77f, size.height * 0.34f)
                drawPath(
                    p, Color.White,
                    style = Stroke(2.6.dp.toPx(), cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
                )
            }
            QLabel("Ascend")
            Box(Modifier.weight(1f))
            ProfileIcon { vm.go(Screen.Settings) }
            ThemeToggle(dark, onToggleTheme)
        }

        Box(Modifier.padding(top = 22.dp))
        Hero("Good", greet)
        Lead(if (name.isNotEmpty()) "$name · $dateText" else dateText)

        val d = store.draft
        if (d != null && d.res.isNotEmpty()) {
            val pct = if (d.res.isEmpty()) 0 else d.answered * 100 / d.res.size
            Card3D(Modifier.padding(bottom = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        Canvas(Modifier.size(54.dp)) {
                            val sw = 5.dp.toPx()
                            drawCircle(c.line, radius = size.width / 2f - sw, style = Stroke(sw))
                            drawArc(
                                color = c.sand, startAngle = -90f, sweepAngle = 360f * pct / 100f, useCenter = false,
                                topLeft = Offset(sw, sw), size = Size(size.width - 2 * sw, size.height - 2 * sw),
                                style = Stroke(sw, cap = StrokeCap.Round)
                            )
                        }
                        Text("$pct%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = c.ink)
                    }
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        QLabel("Pick up where you left")
                        Text(d.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = c.ink, maxLines = 1)
                        Text("${d.answered} of ${d.res.size} answered", fontSize = 13.sp, color = c.muted)
                    }
                }
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Resume", Modifier.weight(1f), fontSp = 16) { vm.resumeDraft() }
                    PillButton(
                        "Discard", Modifier.weight(1f), bg = c.card, fg = c.muted, shadow = c.ink.copy(alpha = 0.1f),
                        border = c.line, fontSp = 16
                    ) { store.putDraft(null) }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction("Practice", Modifier.weight(1f)) { vm.setupHw = null; vm.go(Screen.Setup) }
            QuickAction("Focus", Modifier.weight(1f)) { vm.go(Screen.Focus) }
            QuickAction("Add task", Modifier.weight(1f)) { vm.openHwAdd = true; vm.go(Screen.Homework) }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Tile("Practice", "Questions · Timer", Color(0xFF5E5CE6), 2, Modifier.weight(1f)) {
                vm.setupHw = null
                vm.go(Screen.Setup)
            }
            Tile("Homework", "Plan by date", Color(0xFFFF2D55), 3, Modifier.weight(1f)) { vm.go(Screen.Homework) }
        }
        Box(Modifier.padding(top = 6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Tile("Focus", "Pomodoro timer", Color(0xFFFF9F0A), 0, Modifier.weight(1f)) { vm.go(Screen.Focus) }
            Tile("History", "${store.history.size} saved", Color(0xFF7A7A8C), 1, Modifier.weight(1f)) { vm.go(Screen.History) }
        }
    }
}

@Composable
private fun QuickAction(label: String, modifier: Modifier, onClick: () -> Unit) {
    val c = A.c
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .clip(shape)
            .background(c.card)
            .border(1.5.dp, c.line, shape)
            .tap(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (label == "Add task") PlusIcon(c.ink, Modifier.size(14.dp)) else if (label == "Practice") PlayIcon(c.ink, Modifier.size(14.dp))
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.ink, modifier = Modifier.padding(start = 6.dp))
    }
}

@Composable
fun SettingsScreen(vm: AppVm, dark: Boolean, onToggleTheme: () -> Unit) {
    val c = A.c
    val store = vm.store
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(store.userName) }
    var tab by remember { mutableStateOf(0) }
    var confirmWipe by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(store.exportJson().toByteArray()) }
                Toast.makeText(ctx, "Backup saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Could not save the file", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: ""
                val added = store.importJson(text)
                Toast.makeText(ctx, "Restored $added new item" + (if (added == 1) "" else "s"), Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "That file could not be read", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        TopBar("Home", { vm.back() }) { ThemeToggle(dark, onToggleTheme) }
        Hero("Your", "settings.")
        Lead("Your profile, study options and data.")
        Segmented(listOf("Account", "Sound & feel"), tab, { tab = it })

        if (tab == 0) {
            SectionLabel("Profile")
            InputBox("Your name", name, { name = it }, big = false, maxLen = 40, placeholder = "Shown on Home")
            Box(Modifier.padding(top = 12.dp))
            PillButton("Save", Modifier.fillMaxWidth()) {
                store.setName(name)
                Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
            }
            SectionLabel("Backup")
            SettingRow("Back up to a file") { exportLauncher.launch("ascend-backup.json") }
            SettingRow("Restore from a file") { importLauncher.launch(arrayOf("application/json", "*/*")) }
            Text(
                "The file holds your sessions, homework and subjects. Restoring adds to what is on this device and never removes anything.",
                fontSize = 13.sp, lineHeight = 18.sp, color = c.muted
            )
            SectionLabel("Danger zone")
            if (!confirmWipe) {
                SettingRow("Delete all data on this device", danger = true) { confirmWipe = true }
            } else {
                Text("This removes every session, task and subject. It cannot be undone.", fontSize = 14.sp, color = c.bad, modifier = Modifier.padding(bottom = 10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Cancel", Modifier.weight(1f), bg = c.card, fg = c.ink, shadow = c.ink.copy(alpha = 0.1f), border = c.line, fontSp = 16) { confirmWipe = false }
                    PillButton("Delete", Modifier.weight(1f), bg = c.bad, fg = Color.White, shadow = c.bad.copy(alpha = 0.4f), fontSp = 16) {
                        store.history.toList().forEach { store.deleteRecord(it.id) }
                        store.subjects.toList().forEach { store.deleteSubject(it.id) }
                        store.items.toList().forEach { store.deleteItem(it.id) }
                        store.putDraft(null)
                        confirmWipe = false
                    }
                }
            }
        } else {
            SectionLabel("Appearance")
            Segmented(
                listOf("System", "Light", "Dark"),
                when (store.themeMode) { "light" -> 1; "dark" -> 2; else -> 0 },
                { store.setTheme(when (it) { 1 -> "light"; 2 -> "dark"; else -> "system" }) }
            )
            SectionLabel("Feedback")
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Haptics", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c.ink)
                    Text("A small buzz when you answer, finish or a focus block ends.", fontSize = 12.5.sp, color = c.muted)
                }
                Toggle(store.haptics) { store.updateHaptics(it) }
            }
        }
        Box(Modifier.padding(bottom = 30.dp))
    }
}
