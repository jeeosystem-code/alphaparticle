package com.ascend.app.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.AppVm
import com.ascend.app.Screen
import com.ascend.app.data.fmtMs
import com.ascend.app.data.numStr
import com.ascend.app.ui.A
import com.ascend.app.ui.Card3D
import com.ascend.app.ui.FlatCard
import com.ascend.app.ui.Hero
import com.ascend.app.ui.InputBox
import com.ascend.app.ui.Lead
import com.ascend.app.ui.PillButton
import com.ascend.app.ui.QLabel
import com.ascend.app.ui.Segmented
import com.ascend.app.ui.StepperRow
import com.ascend.app.ui.ThemeToggle
import com.ascend.app.ui.Toggle
import com.ascend.app.ui.TopBar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- focus timer

private val presets = listOf(
    listOf(25, 5, 15, 4),
    listOf(50, 10, 20, 3),
    listOf(90, 15, 30, 2)
)

private fun clock(ms: Long): String {
    val s = Math.ceil(ms / 1000.0).toLong()
    val m = s / 60
    val r = s % 60
    return String.format(Locale.US, "%02d:%02d", m, r)
}

@Composable
fun FocusScreen(vm: AppVm, dark: Boolean, onToggleTheme: () -> Unit) {
    val c = A.c
    val store = vm.store
    val p = vm.pomo

    Column(Modifier.fillMaxWidth()) {
        TopBar("Practice", { vm.back() }) { ThemeToggle(dark, onToggleTheme) }
        Hero("Focus", "timer.")

        if (p.phase == "idle") {
            Lead("Study in focused blocks with short breaks, without marking each question.")
            val cur = listOf(store.pmFocus, store.pmShort, store.pmLong, store.pmBlocks)
            val sel = presets.indexOf(cur)
            Segmented(listOf("25 / 5", "50 / 10", "90 / 15"), if (sel >= 0) sel else -1, {
                val q = presets[it]
                store.pmFocus = q[0]; store.pmShort = q[1]; store.pmLong = q[2]; store.pmBlocks = q[3]
                store.savePomo()
            })
            Box(Modifier.padding(top = 14.dp))
            FlatCard {
                StepperRow("Focus", "Minutes of work in each block", store.pmFocus, { store.pmFocus = it; store.savePomo() }, 1, 180)
                StepperRow("Short break", "Minutes between blocks", store.pmShort, { store.pmShort = it; store.savePomo() }, 1, 60)
                StepperRow("Long break", "Minutes after a full round", store.pmLong, { store.pmLong = it; store.savePomo() }, 1, 90)
                StepperRow("Blocks per round", "Focus blocks before a long break", store.pmBlocks, { store.pmBlocks = it; store.savePomo() }, 1, 12)
            }
            Box(Modifier.padding(top = 12.dp))
            InputBox(
                "What are you studying? (optional)", p.label, { p.label = it }, big = false, maxLen = 40,
                placeholder = "e.g. Physics, Kinematics"
            )
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Auto-start next block", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c.ink)
                    Text("Breaks and blocks follow each other by themselves.", fontSize = 12.5.sp, color = c.muted)
                }
                Toggle(store.pmAuto) { store.pmAuto = it; store.savePomo() }
            }
            val round = store.pmFocus * store.pmBlocks
            Text(
                "A round is ${store.pmBlocks} × ${store.pmFocus} min = $round min of focus · total focused so far ${store.pmFocusTotalMin} min",
                fontSize = 13.sp, color = c.muted, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
            )
            PillButton("Start focus", Modifier.fillMaxWidth()) {
                vm.tick()
                p.start()
            }
        } else {
            val title = when (p.phase) {
                "focus" -> "Focus"
                "short" -> "Short break"
                else -> "Long break"
            }
            Lead(if (p.label.isNotEmpty()) p.label else if (p.phase == "focus") "Stay with it." else "Step away for a moment.")
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(250.dp)) {
                    val sw = 12.dp.toPx()
                    drawCircle(c.line, radius = size.width / 2f - sw, style = Stroke(sw))
                    drawArc(
                        color = if (p.phase == "focus") c.sand else c.good,
                        startAngle = -90f, sweepAngle = 360f * p.progress(), useCenter = false,
                        topLeft = Offset(sw, sw), size = Size(size.width - 2 * sw, size.height - 2 * sw),
                        style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    QLabel(title)
                    Text(
                        clock(p.remaining()), fontSize = 54.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1.5).sp,
                        color = c.ink, style = TextStyle(fontFeatureSettings = "tnum")
                    )
                    Text(
                        if (p.waiting) "Ready for the next one" else if (!p.running) "Paused" else "Block ${p.blocks + (if (p.phase == "focus") 1 else 0)} of ${store.pmBlocks}",
                        fontSize = 13.sp, color = c.muted
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 18.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                for (i in 0 until store.pmBlocks) {
                    Box(
                        Modifier
                            .padding(horizontal = 5.dp)
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (i < p.blocks) c.sand else c.line)
                    )
                }
            }
            if (p.waiting) {
                PillButton("Start " + (if (p.phase == "focus") "focus" else "break"), Modifier.fillMaxWidth()) {
                    vm.tick()
                    p.startNext()
                }
            } else {
                PillButton(if (p.running) "Pause" else "Resume", Modifier.fillMaxWidth()) {
                    vm.tick()
                    p.pauseResume()
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(
                    "Skip", Modifier.weight(1f), bg = c.card, fg = c.ink, shadow = c.ink.copy(alpha = 0.1f),
                    border = c.line, fontSp = 16
                ) { p.skip() }
                PillButton(
                    "End", Modifier.weight(1f), bg = c.card, fg = c.bad, shadow = c.ink.copy(alpha = 0.1f),
                    border = c.line, fontSp = 16
                ) { p.stop() }
            }
            Text(
                "This session: ${p.sessionMinutes} min focused",
                fontSize = 13.sp, color = c.muted, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Text(
                "Keep the app open while the timer runs.",
                fontSize = 12.sp, color = c.muted, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
        Box(Modifier.padding(bottom = 30.dp))
    }
}

// ---------------------------------------------------------------- history

@Composable
fun HistoryScreen(vm: AppVm, dark: Boolean, onToggleTheme: () -> Unit) {
    val c = A.c
    val h = vm.store.history
    val fmt = SimpleDateFormat("d MMM · HH:mm", Locale.getDefault())

    Column(Modifier.fillMaxWidth()) {
        TopBar("Back", { vm.back() }) { ThemeToggle(dark, onToggleTheme) }
        Hero("Your", "history.")
        Lead(
            if (h.isEmpty()) "Saved on this device. Nothing leaves it."
            else "${h.size} session" + (if (h.size == 1) "" else "s") + " · ${fmtMs(h.sumOf { it.totalMs })} practised · saved on this device"
        )
        if (h.isEmpty()) {
            Text("Finished practice sessions show up here.", fontSize = 15.sp, color = c.muted)
        }
        h.forEach { r ->
            Card3D(Modifier.padding(bottom = 10.dp), radius = 22.dp, onClick = { vm.go(Screen.HistoryView(r.id)) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(fmt.format(Date(r.date)), fontSize = 12.5.sp, color = c.muted)
                        Text(
                            "${r.att} attempted · ${r.skipped} skipped · ${fmtMs(r.totalMs)}",
                            fontSize = 12.5.sp, color = c.muted, modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(numStr(r.score), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = c.ink)
                        Text("/ ${numStr(r.max)}", fontSize = 12.5.sp, color = c.muted)
                    }
                }
            }
        }
        Box(Modifier.padding(bottom = 30.dp))
    }
}
