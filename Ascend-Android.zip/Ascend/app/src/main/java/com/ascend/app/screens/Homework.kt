package com.ascend.app.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ascend.app.AppVm
import com.ascend.app.Screen
import com.ascend.app.data.HwItem
import com.ascend.app.data.newId
import com.ascend.app.ui.A
import com.ascend.app.ui.Chip
import com.ascend.app.ui.FlatCard
import com.ascend.app.ui.Hero
import com.ascend.app.ui.InputBox
import com.ascend.app.ui.Lead
import com.ascend.app.ui.PillButton
import com.ascend.app.ui.QLabel
import com.ascend.app.ui.Segmented
import com.ascend.app.ui.StepBtn
import com.ascend.app.ui.SubjectColors
import com.ascend.app.ui.ThemeToggle
import com.ascend.app.ui.TopBar
import com.ascend.app.ui.tap
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

private fun todayKey(): String = LocalDate.now().toString()

private fun parseDate(s: String): LocalDate? = try {
    LocalDate.parse(s)
} catch (e: Exception) {
    null
}

private fun dateLabel(s: String): String {
    val d = parseDate(s) ?: return "No date"
    val diff = ChronoUnit.DAYS.between(LocalDate.now(), d)
    return when (diff) {
        0L -> "Today"
        1L -> "Tomorrow"
        -1L -> "Yesterday"
        else -> d.format(DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()))
    }
}

private fun prRank(p: Int): Int = if (p in 1..3) p else 9

private val prNames = listOf("None", "High", "Medium", "Low")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeworkScreen(vm: AppVm, dark: Boolean, onToggleTheme: () -> Unit) {
    val c = A.c
    val store = vm.store
    var view by remember { mutableStateOf(0) }
    var subFilter by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<HwItem?>(null) }
    var isNew by remember { mutableStateOf(false) }
    var confirmSub by remember { mutableStateOf(false) }

    fun newItem(): HwItem = HwItem(
        newId(), store.subjects.firstOrNull()?.id ?: "", "", todayKey(), 0, 0, 0, "", false, emptyList()
    )

    LaunchedEffect(Unit) {
        if (vm.openHwAdd) {
            vm.openHwAdd = false
            editing = newItem()
            isNew = true
        }
    }

    val today = todayKey()
    val all = store.items.filter { subFilter.isEmpty() || it.subjectId == subFilter }
    val upcoming = all.filter { !it.done && it.date >= today }
    val overdue = all.filter { !it.done && it.date < today }
    val done = all.filter { it.done }
    val picked: List<HwItem> = when (view) {
        0 -> upcoming
        1 -> overdue
        2 -> done
        else -> all
    }
    val shown = picked.sortedWith(compareBy<HwItem>({ it.date }, { prRank(it.priority) }, { it.title }))

    Column(Modifier.fillMaxWidth()) {
        TopBar("Home", { vm.back() }) { ThemeToggle(dark, onToggleTheme) }
        Hero("Your", "homework.")
        Lead(
            if (store.items.isEmpty()) "Plan what to finish, and by when."
            else "${upcoming.size} to do · ${overdue.size} overdue · ${done.size} done"
        )
        PillButton("Add homework", Modifier.fillMaxWidth(), fontSp = 17) {
            editing = newItem()
            isNew = true
        }
        Box(Modifier.padding(top = 10.dp))
        Segmented(
            listOf("Upcoming", "Overdue " + overdue.size, "Done", "All"), view, { view = it; confirmSub = false }
        )

        if (store.subjects.isNotEmpty()) {
            FlowRow(
                Modifier.padding(top = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip("All", subFilter.isEmpty(), c.sand) { subFilter = ""; confirmSub = false }
                store.subjects.forEach { s ->
                    Chip(s.name, subFilter == s.id, SubjectColors[s.color % SubjectColors.size]) {
                        subFilter = s.id
                        confirmSub = false
                    }
                }
            }
            if (subFilter.isNotEmpty()) {
                Text(
                    if (confirmSub) "TAP AGAIN TO DELETE SUBJECT AND ITS TASKS" else "DELETE SUBJECT",
                    fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp, color = c.bad,
                    modifier = Modifier
                        .tap {
                            if (confirmSub) {
                                store.deleteSubject(subFilter)
                                subFilter = ""
                                confirmSub = false
                            } else confirmSub = true
                        }
                        .padding(vertical = 10.dp)
                )
            }
        }

        Box(Modifier.padding(top = 10.dp))
        if (shown.isEmpty()) {
            Text(
                when (view) {
                    0 -> "Nothing coming up. Add homework to plan it."
                    1 -> "Nothing overdue."
                    2 -> "Finished homework shows up here."
                    else -> "No homework yet."
                },
                fontSize = 15.sp, color = c.muted, modifier = Modifier.padding(vertical = 12.dp)
            )
        }
        var lastDate = ""
        shown.forEach { item ->
            if (item.date != lastDate) {
                lastDate = item.date
                QLabel(dateLabel(item.date), Modifier.padding(top = 12.dp, bottom = 8.dp), color = if (item.date < today && !item.done) c.bad else c.muted)
            }
            HwRow(vm, item) {
                editing = item
                isNew = false
            }
        }
        Box(Modifier.padding(bottom = 30.dp))
    }

    val ed = editing
    if (ed != null) {
        HwDialog(vm, ed, isNew) { editing = null }
    }
}

@Composable
private fun HwRow(vm: AppVm, item: HwItem, onEdit: () -> Unit) {
    val c = A.c
    val store = vm.store
    val sub = store.subjects.firstOrNull { it.id == item.subjectId }
    val col = if (sub != null) SubjectColors[sub.color % SubjectColors.size] else c.muted
    FlatCard(Modifier.padding(bottom = 10.dp).tap(onClick = onEdit)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (item.done) c.good else Color.Transparent)
                    .border(2.dp, if (item.done) c.good else col, CircleShape)
                    .tap { store.putItem(item.copy(done = !item.done)) },
                contentAlignment = Alignment.Center
            ) {
                if (item.done) {
                    Canvas(Modifier.size(14.dp)) {
                        drawLine(c.goodT, Offset(size.width * 0.15f, size.height * 0.55f), Offset(size.width * 0.4f, size.height * 0.8f), 2.2.dp.toPx(), StrokeCap.Round)
                        drawLine(c.goodT, Offset(size.width * 0.4f, size.height * 0.8f), Offset(size.width * 0.88f, size.height * 0.22f), 2.2.dp.toPx(), StrokeCap.Round)
                    }
                }
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    item.title, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                    color = if (item.done) c.muted else c.ink,
                    textDecoration = if (item.done) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                val bits = ArrayList<String>()
                if (sub != null) bits.add(sub.name)
                if (item.hasRange) bits.add("Q${item.from}–${item.to}")
                if (item.priority in 1..3) bits.add(prNames[item.priority] + " priority")
                if (bits.isNotEmpty()) Text(bits.joinToString(" · "), fontSize = 12.5.sp, color = col, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (item.hasRange) {
                    Canvas(Modifier.fillMaxWidth().height(6.dp).padding(top = 0.dp)) {
                        drawRoundRect(c.line, Offset.Zero, Size(size.width, size.height), CornerRadius(size.height / 2f))
                        if (item.progress > 0f) {
                            drawRoundRect(col, Offset.Zero, Size(size.width * item.progress, size.height), CornerRadius(size.height / 2f))
                        }
                    }
                    Text(
                        "${item.numbers.size - item.left.size} of ${item.numbers.size} attempted",
                        fontSize = 11.5.sp, color = c.muted, modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
            if (item.hasRange && !item.done) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(c.btn)
                        .tap {
                            vm.setupHw = item
                            vm.go(Screen.Setup)
                        },
                    contentAlignment = Alignment.Center
                ) { com.ascend.app.ui.PlayIcon(c.btnT, Modifier.size(16.dp)) }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HwDialog(vm: AppVm, init: HwItem, isNew: Boolean, onClose: () -> Unit) {
    val c = A.c
    val store = vm.store
    var title by remember { mutableStateOf(init.title) }
    var subId by remember { mutableStateOf(init.subjectId) }
    var date by remember { mutableStateOf(init.date) }
    var pr by remember { mutableStateOf(init.priority) }
    var from by remember { mutableStateOf(if (init.from > 0) init.from.toString() else "") }
    var to by remember { mutableStateOf(if (init.to > 0) init.to.toString() else "") }
    var note by remember { mutableStateOf(init.note) }
    var newSub by remember { mutableStateOf("") }
    var newCol by remember { mutableStateOf(0) }
    var err by remember { mutableStateOf("") }
    var confirmDel by remember { mutableStateOf(false) }

    val shape = RoundedCornerShape(26.dp)
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(14.dp)
                .clip(shape)
                .background(c.bg)
                .border(1.5.dp, c.line, shape)
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Text(
                if (isNew) "New homework" else "Edit homework",
                fontSize = 24.sp, fontWeight = FontWeight.Bold, color = c.ink, modifier = Modifier.padding(bottom = 14.dp)
            )
            InputBox("Title", title, { title = it }, big = false, placeholder = "e.g. Kinematics DPP 03")

            QLabel("Subject", Modifier.padding(top = 16.dp, bottom = 8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("None", subId.isEmpty(), c.muted) { subId = "" }
                store.subjects.forEach { s ->
                    Chip(s.name, subId == s.id, SubjectColors[s.color % SubjectColors.size]) { subId = s.id }
                }
            }
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InputBox("New subject", newSub, { newSub = it }, Modifier.weight(1f), big = false, maxLen = 24, placeholder = "e.g. Physics")
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(SubjectColors[newCol % SubjectColors.size])
                        .tap { newCol = (newCol + 1) % SubjectColors.size }
                )
                Text(
                    "ADD", fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = c.pause,
                    modifier = Modifier
                        .tap {
                            if (newSub.trim().isNotEmpty()) {
                                val s = store.addSubject(newSub, newCol)
                                subId = s.id
                                newSub = ""
                            }
                        }
                        .padding(8.dp)
                )
            }

            QLabel("Due date", Modifier.padding(top = 16.dp, bottom = 8.dp))
            val ld = parseDate(date) ?: LocalDate.now()
            Row(verticalAlignment = Alignment.CenterVertically) {
                StepBtn("−") { date = ld.minusDays(1).toString() }
                Text(
                    dateLabel(ld.toString()) + " · " + ld.format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())),
                    fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c.ink,
                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp), maxLines = 1
                )
                StepBtn("+") { date = ld.plusDays(1).toString() }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Today", date == todayKey(), c.sand) { date = todayKey() }
                Chip("Tomorrow", date == LocalDate.now().plusDays(1).toString(), c.sand) { date = LocalDate.now().plusDays(1).toString() }
                Chip("Next week", date == LocalDate.now().plusDays(7).toString(), c.sand) { date = LocalDate.now().plusDays(7).toString() }
            }

            QLabel("Priority", Modifier.padding(top = 16.dp, bottom = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                prNames.forEachIndexed { i, n -> Chip(n, pr == i, c.sand) { pr = i } }
            }

            QLabel("Questions (optional)", Modifier.padding(top = 16.dp, bottom = 8.dp))
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InputBox("From", from, { from = it.filter { ch -> ch.isDigit() } }, Modifier.weight(1f), number = true, maxLen = 4, placeholder = "1")
                InputBox("To", to, { to = it.filter { ch -> ch.isDigit() } }, Modifier.weight(1f), number = true, maxLen = 4, placeholder = "20")
            }
            Box(Modifier.padding(top = 12.dp))
            InputBox("Note", note, { note = it }, big = false, maxLen = 120, placeholder = "Optional")

            Text(
                err, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.bad,
                modifier = Modifier.padding(vertical = 10.dp)
            )
            PillButton("Save", Modifier.fillMaxWidth(), fontSp = 17) {
                val f = from.toIntOrNull() ?: 0
                val t = to.toIntOrNull() ?: 0
                if (title.trim().isEmpty()) {
                    err = "Give it a title."
                } else if ((f > 0 || t > 0) && (f < 1 || t < f)) {
                    err = "Enter a valid question range, or leave both empty."
                } else if (t - f + 1 > 300) {
                    err = "Keep a range to 300 questions or fewer."
                } else {
                    store.putItem(init.copy(title = title.trim(), subjectId = subId, date = date, priority = pr, from = f, to = t, note = note.trim()))
                    onClose()
                }
            }
            if (!isNew) {
                Box(Modifier.padding(top = 4.dp))
                if (!confirmDel) {
                    PillButton("Delete", Modifier.fillMaxWidth(), bg = c.card, fg = c.bad, shadow = c.ink.copy(alpha = 0.1f), border = c.line, fontSp = 16) {
                        confirmDel = true
                    }
                } else {
                    PillButton("Tap again to delete", Modifier.fillMaxWidth(), bg = c.bad, fg = Color.White, shadow = c.bad.copy(alpha = 0.4f), fontSp = 16) {
                        store.deleteItem(init.id)
                        onClose()
                    }
                }
            }
            Text(
                "CANCEL", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.1.sp, color = c.muted,
                modifier = Modifier
                    .fillMaxWidth()
                    .tap(onClick = onClose)
                    .padding(14.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
