package com.ascend.app.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.ascend.app.AppVm
import com.ascend.app.Screen
import com.ascend.app.SessionEngine
import com.ascend.app.data.SessionRec
import com.ascend.app.data.fmtMs
import com.ascend.app.data.numStr
import com.ascend.app.ui.A
import com.ascend.app.ui.Card3D
import com.ascend.app.ui.Chip
import com.ascend.app.ui.ChevronBack
import com.ascend.app.ui.Hero
import com.ascend.app.ui.InputBox
import com.ascend.app.ui.Lead
import com.ascend.app.ui.PillButton
import com.ascend.app.ui.QLabel
import com.ascend.app.ui.RoundBtn
import com.ascend.app.ui.SectionLabel
import com.ascend.app.ui.ThemeToggle
import com.ascend.app.ui.TopBar
import com.ascend.app.ui.tap
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- setup

@Composable
fun SetupScreen(vm: AppVm, dark: Boolean, onToggleTheme: () -> Unit) {
    val c = A.c
    val store = vm.store
    val hw = vm.setupHw
    var name by remember { mutableStateOf(hw?.title ?: "") }
    var from by remember { mutableStateOf(if (hw != null && hw.hasRange) hw.from.toString() else "") }
    var to by remember { mutableStateOf(if (hw != null && hw.hasRange) hw.to.toString() else "") }
    var pos by remember { mutableStateOf(numStr(store.lastPos)) }
    var neg by remember { mutableStateOf(numStr(store.lastNeg)) }
    var err by remember { mutableStateOf("") }

    val f = from.toIntOrNull() ?: 0
    val t = to.toIntOrNull() ?: 0
    val p = pos.toDoubleOrNull() ?: -1.0
    val n = if (neg.isEmpty()) 0.0 else (neg.toDoubleOrNull() ?: -1.0)

    fun validate(): String {
        if (f < 1 || t < 1) return "Enter a valid question range (starting from 1 or more)."
        if (t < f) return "The last question must be the same as or after the first."
        if (t - f + 1 > 300) return "Please keep a session to 300 questions or fewer."
        if (p < 0) return "Enter the marks for a correct answer."
        if (n < 0) return "Enter the negative marks (use 0 for none)."
        return ""
    }

    fun start() {
        val e = validate()
        err = e
        if (e.isNotEmpty()) return
        val title = if (name.trim().isEmpty()) "Untitled task" else name.trim()
        vm.startPractice(title, f, t, p, n, hw?.id)
    }

    val sum = if (validate().isEmpty()) {
        val q = t - f + 1
        "$q question" + (if (q > 1) "s" else "") + " · max " + numStr(q * p) + " marks"
    } else ""

    Column(Modifier.fillMaxWidth()) {
        TopBar("Back", { vm.back() }) { ThemeToggle(dark, onToggleTheme) }
        Hero("Plan your", "session.")
        Lead("Tell me what you're solving. I'll keep the clock, the palette and the score.")

        QLabel("Task name", Modifier.padding(bottom = 8.dp))
        InputBox("Name", name, { name = it }, big = false, placeholder = "e.g. Physics DPP 07")

        QLabel("Questions to attempt", Modifier.padding(top = 18.dp, bottom = 8.dp))
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InputBox("From", from, { from = it.filter { ch -> ch.isDigit() } }, Modifier.weight(1f), placeholder = "1", number = true, maxLen = 4)
            Text("→", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = c.muted, modifier = Modifier.padding(bottom = 18.dp))
            InputBox("To", to, { to = it.filter { ch -> ch.isDigit() } }, Modifier.weight(1f), placeholder = "20", number = true, maxLen = 4)
        }

        QLabel("Marks per question", Modifier.padding(top = 18.dp, bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InputBox("Correct +", pos, { pos = it }, Modifier.weight(1f), decimal = true, maxLen = 5)
            InputBox("Wrong −", neg, { neg = it }, Modifier.weight(1f), decimal = true, maxLen = 5)
        }

        Text(
            sum, fontSize = 15.sp, color = c.muted, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 4.dp)
        )
        Text(
            err, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.bad, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
        )
        PillButton("Start session", Modifier.fillMaxWidth()) { start() }
        Box(Modifier.padding(bottom = 30.dp))
    }
}

// ---------------------------------------------------------------- live session

@Composable
fun SessionScreen(vm: AppVm) {
    val s = vm.session
    if (s == null) {
        LaunchedEffect(Unit) { vm.back() }
        return
    }
    val c = A.c
    var showLeave by remember { mutableStateOf(false) }

    LaunchedEffect(s.phase) {
        while (s.phase == 1) {
            s.now = System.currentTimeMillis()
            delay(200)
        }
    }
    LaunchedEffect(s.idx, s.phase) {
        if (s.phase == 1) vm.saveDraft()
    }

    fun onBack() {
        if (s.phase == 1) showLeave = true else vm.leaveSession(false)
    }
    BackHandler(enabled = true) { onBack() }

    val cur = s.res[s.idx.coerceIn(0, s.res.size - 1)]

    Box(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundBtn({ onBack() }) { ChevronBack(c.ink, Modifier.size(15.dp)) }
                Box(Modifier.weight(1f))
                QLabel("Q ${cur.no} · ${s.idx + 1} of ${s.n}")
            }
            Text(
                s.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp, color = c.ink,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
            )

            Palette(s)
            Legend()

            Column(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val e = if (s.phase == 1) s.elapsed() else 0L
                Hourglass(if (s.phase == 1) ((e % 60000L) / 60000f) else 0f, s.paused)
                val tr = rememberInfiniteTransition(label = "blink")
                val blink by tr.animateFloat(
                    initialValue = 1f, targetValue = 0.4f,
                    animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "a"
                )
                Text(
                    fmtMs(e), fontSize = 64.sp, fontWeight = FontWeight.Bold, letterSpacing = (-2).sp, color = c.ink,
                    style = TextStyle(fontFeatureSettings = "tnum"),
                    modifier = Modifier.padding(top = 6.dp).alpha(if (s.paused) blink else 1f)
                )
                val r = cur
                val hint = when {
                    s.phase == 0 -> "Ready when you are"
                    s.paused -> "Paused"
                    r.st != null -> "Revisiting"
                    r.t > 0 -> "Continuing"
                    else -> "Solving…"
                }
                QLabel(hint, Modifier.padding(top = 4.dp))
            }

            // marks strip
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 14.dp)
                    .drawBehind {
                        drawLine(c.line, Offset(0f, 0f), Offset(size.width, 0f), 1.5.dp.toPx())
                        drawLine(c.line, Offset(0f, size.height), Offset(size.width, size.height), 1.5.dp.toPx())
                    }
            ) {
                Stat("Attempted", s.attempted.toString(), Modifier.weight(1f))
                Stat("Skipped", s.skipped.toString(), Modifier.weight(1f))
                Stat("Score", numStr(s.score), Modifier.weight(1f))
                Stat("Max", numStr(s.max), Modifier.weight(1f))
            }

            Box(Modifier.padding(top = 14.dp))
            if (s.phase == 0) {
                PillButton("Start", Modifier.fillMaxWidth()) {
                    vm.tick()
                    s.begin()
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PillButton(
                        "Attempted", Modifier.weight(1f), bg = c.good, fg = c.goodT,
                        shadow = c.good.copy(alpha = 0.45f), fontSp = 16
                    ) {
                        vm.tick()
                        if (s.answer("A")) vm.finishSession()
                    }
                    PillButton(
                        "Not attempted", Modifier.weight(1f), bg = c.bad.copy(alpha = 0.12f), fg = c.bad,
                        shadow = c.bad.copy(alpha = 0.22f), border = c.bad.copy(alpha = 0.7f), fontSp = 16
                    ) {
                        vm.tick()
                        if (s.answer("N")) vm.finishSession()
                    }
                }
                val armed = s.now < s.stopArmedUntil
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 30.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        if (s.paused) "Resume" else "Pause", fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.1.sp, color = c.pause,
                        modifier = Modifier.tap { s.togglePause() }.padding(14.dp)
                    )
                    Text(
                        if (armed) "TAP AGAIN TO FINISH" else "FINISH", fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.1.sp, color = if (armed) c.bad else c.muted,
                        modifier = Modifier.tap {
                            val t = System.currentTimeMillis()
                            if (t >= s.stopArmedUntil) {
                                s.stopArmedUntil = t + 3000
                            } else {
                                vm.finishSession()
                            }
                        }.padding(14.dp)
                    )
                }
            }
        }

        if (showLeave) {
            Dialog(onDismissRequest = { showLeave = false }) {
                Card3D(Modifier.padding(8.dp)) {
                    Text("Leave this session?", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = c.ink)
                    Text(
                        "Your answers are kept. Save it to carry on later from Home.",
                        fontSize = 14.sp, color = c.muted, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp)
                    )
                    PillButton("Save and leave", Modifier.fillMaxWidth(), fontSp = 16) {
                        showLeave = false
                        vm.leaveSession(true)
                    }
                    PillButton(
                        "Discard", Modifier.fillMaxWidth().padding(top = 6.dp), bg = c.card, fg = c.bad,
                        shadow = c.ink.copy(alpha = 0.1f), border = c.line, fontSp = 16
                    ) {
                        showLeave = false
                        vm.leaveSession(false)
                    }
                    Text(
                        "KEEP GOING", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.1.sp, color = c.muted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().tap { showLeave = false }.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    val c = A.c
    Column(modifier.padding(vertical = 8.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.55.sp, color = c.muted, maxLines = 1)
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 1)
    }
}

@Composable
private fun Legend() {
    val c = A.c
    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        LegendDot(c.good, "Attempted")
        LegendDot(c.bad, "Skipped")
        LegendDot(c.sand, "Current")
        LegendDot(Color.Transparent, "Pending", dashed = true)
    }
}

@Composable
private fun LegendDot(color: Color, label: String, dashed: Boolean = false) {
    val c = A.c
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(9.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
                .then(if (dashed) Modifier.border(1.5.dp, c.sand, RoundedCornerShape(3.dp)) else Modifier)
        )
        Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp, color = c.muted, modifier = Modifier.padding(start = 5.dp), maxLines = 1)
    }
}

@Composable
private fun Palette(s: SessionEngine) {
    val c = A.c
    val gridState = rememberLazyGridState()
    BoxWithConstraints(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        val gap = 6.dp
        val pad = 4.dp
        val cell = (maxWidth - pad * 2 - gap * 7) / 8
        val rows = if (s.n > 8) 2 else 1
        val h = cell * rows + gap * (rows - 1) + pad * 2
        LaunchedEffect(s.idx) {
            val row = (s.idx / 8 - 1).coerceAtLeast(0)
            gridState.animateScrollToItem(row * 8)
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(8),
            state = gridState,
            modifier = Modifier.fillMaxWidth().height(h),
            contentPadding = PaddingValues(pad),
            horizontalArrangement = Arrangement.spacedBy(gap),
            verticalArrangement = Arrangement.spacedBy(gap)
        ) {
            items(s.n) { i ->
                val r = s.res[i]
                val isCur = i == s.idx && s.phase != 2
                val shape = RoundedCornerShape(10.dp)
                val bg: Color
                val bd: Color
                val tx: Color
                if (isCur) {
                    bg = c.sand; bd = c.ink; tx = Color(0xFF1B1A17)
                } else if (r.st == "A") {
                    bg = c.good.copy(alpha = 0.18f); bd = c.good; tx = c.good
                } else if (r.st == "N") {
                    bg = c.bad.copy(alpha = 0.12f); bd = c.bad.copy(alpha = 0.55f); tx = c.bad
                } else {
                    bg = Color.Transparent; bd = c.line; tx = c.muted
                }
                val pending = !isCur && r.st == null && r.t > 0
                Box(
                    Modifier
                        .size(cell)
                        .clip(shape)
                        .background(bg)
                        .drawBehind {
                            val sw = 1.5.dp.toPx()
                            if (pending) {
                                drawRoundRect(
                                    c.sand, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw),
                                    CornerRadius(10.dp.toPx()),
                                    style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                                )
                            } else {
                                drawRoundRect(
                                    bd, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw),
                                    CornerRadius(10.dp.toPx()), style = Stroke(sw)
                                )
                            }
                        }
                        .tap { s.jump(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(r.no.toString(), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = tx, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun Hourglass(frac: Float, paused: Boolean) {
    val c = A.c
    Canvas(Modifier.width(78.dp).height(104.dp)) {
        val w = size.width
        val h = size.height
        val capH = 5.dp.toPx()
        val top = Path().apply {
            moveTo(w * 0.1f, capH); lineTo(w * 0.9f, capH); lineTo(w * 0.5f, h / 2f); close()
        }
        val bottom = Path().apply {
            moveTo(w * 0.1f, h - capH); lineTo(w * 0.9f, h - capH); lineTo(w * 0.5f, h / 2f); close()
        }
        val sandColor = if (paused) c.sand2.copy(alpha = 0.5f) else c.sand2
        val f = frac.coerceIn(0f, 1f)
        val half = h / 2f - capH
        clipPath(top) {
            drawRect(sandColor, Offset(0f, capH + half * f), Size(w, half * (1f - f) + 2f))
        }
        clipPath(bottom) {
            drawRect(sandColor, Offset(0f, h - capH - half * f), Size(w, half * f + 2f))
        }
        val sw = 3.dp.toPx()
        drawPath(top, c.glass, style = Stroke(sw, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        drawPath(bottom, c.glass, style = Stroke(sw, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        drawLine(c.glass, Offset(0f, capH / 2), Offset(w, capH / 2), sw * 1.4f, StrokeCap.Round)
        drawLine(c.glass, Offset(0f, h - capH / 2), Offset(w, h - capH / 2), sw * 1.4f, StrokeCap.Round)
    }
}

// ---------------------------------------------------------------- result

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ResultScreen(vm: AppVm, dark: Boolean, onToggleTheme: () -> Unit, recId: String, fresh: Boolean) {
    val c = A.c
    val store = vm.store
    val rec: SessionRec? = store.history.firstOrNull { it.id == recId } ?: vm.lastRecord
    if (rec == null) {
        LaunchedEffect(Unit) { vm.back() }
        return
    }
    var renaming by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf(rec.name) }
    var confirmDel by remember { mutableStateOf(false) }
    val multiDoubt = rec.res.count { it.d }

    fun leave() {
        if (fresh) {
            vm.session = null
            vm.home()
        } else vm.back()
    }

    Column(Modifier.fillMaxWidth()) {
        TopBar(if (fresh) "Home" else "History", { leave() }) { ThemeToggle(dark, onToggleTheme) }
        QLabel(if (fresh) "Session complete" else SimpleDateFormat("d MMM yyyy · HH:mm", Locale.getDefault()).format(Date(rec.date)), color = c.sand)
        if (renaming) {
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InputBox("Name", newName, { newName = it }, Modifier.weight(1f), big = false)
                PillButton("Save", Modifier.width(96.dp), fontSp = 15) {
                    if (newName.trim().isNotEmpty()) store.updateRecord(rec.copy(name = newName.trim()))
                    renaming = false
                }
            }
        } else {
            Text(
                rec.name, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp, color = c.ink,
                modifier = Modifier.padding(top = 6.dp).tap { newName = rec.name; renaming = true }
            )
        }
        Text(numStr(rec.score), fontSize = 76.sp, fontWeight = FontWeight.Bold, letterSpacing = (-3).sp, color = c.ink, modifier = Modifier.padding(top = 10.dp))
        Text("out of ${numStr(rec.max)} marks", fontSize = 15.sp, color = c.muted, modifier = Modifier.padding(bottom = 16.dp))

        val acc = if (rec.att > 0) (rec.correct * 100 / rec.att).toString() + "%" else "—"
        val fast = rec.fastest
        val slow = rec.slowest
        val boxes = listOf(
            Triple("Attempted", rec.att.toString(), "${rec.correct} correct · ${rec.wrong} wrong"),
            Triple("Not attempted", rec.skipped.toString(), ""),
            Triple("Total time", fmtMs(rec.totalMs), ""),
            Triple("Avg / question", if (rec.visited > 0) fmtMs(rec.avgMs) else "—", if (rec.visited > 0) "over ${rec.visited} answered" else ""),
            Triple("Fastest", if (fast != null) fmtMs(fast.t) else "—", if (fast != null) "Q${fast.no}" else ""),
            Triple("Slowest", if (slow != null) fmtMs(slow.t) else "—", if (slow != null) "Q${slow.no}" else ""),
            Triple("Unanswered", rec.unanswered.toString(), ""),
            Triple("Accuracy", acc, "")
        )
        boxes.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { (l, v, sub) ->
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(18.dp))
                            .background(c.card)
                            .border(1.5.dp, c.line, RoundedCornerShape(18.dp))
                            .padding(12.dp)
                    ) {
                        QLabel(l)
                        Text(v, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = c.ink, modifier = Modifier.padding(top = 2.dp), maxLines = 1)
                        if (sub.isNotEmpty()) Text(sub, fontSize = 12.5.sp, color = c.muted, maxLines = 1)
                    }
                }
            }
        }

        SectionLabel("Time per question")
        val maxT = (rec.res.maxOfOrNull { it.t } ?: 1L).coerceAtLeast(1L)
        Canvas(Modifier.fillMaxWidth().height(90.dp)) {
            val n = rec.res.size.coerceAtLeast(1)
            val gap = if (n > 60) 0.5.dp.toPx() else 2.dp.toPx()
            val bw = (size.width - gap * (n - 1)) / n
            rec.res.forEachIndexed { i, r ->
                val hh = if (r.t <= 0) 3.dp.toPx() else (size.height * r.t / maxT).coerceAtLeast(5.dp.toPx())
                val col = when {
                    r.st == "A" && r.w -> c.bad
                    r.st == "A" -> c.good
                    r.st == "N" -> c.muted.copy(alpha = 0.6f)
                    else -> c.line
                }
                drawRoundRect(col, Offset(i * (bw + gap), size.height - hh), Size(bw, hh), CornerRadius(2.dp.toPx()))
            }
        }

        if (rec.att > 0) {
            SectionLabel("Review · tap to mark wrong")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rec.res.forEachIndexed { i, r ->
                    if (r.st == "A") {
                        Chip("Q${r.no}" + (if (r.w) " ✗" else " ✓"), true, if (r.w) c.bad else c.good) {
                            store.updateRecord(rec.copy(res = rec.res.mapIndexed { k, q -> if (k == i) q.copy(w = !q.w) else q }))
                        }
                    }
                }
            }
        }

        SectionLabel(if (multiDoubt > 0) "Your doubts · $multiDoubt" else "Mark your doubts")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            rec.res.forEachIndexed { i, r ->
                Chip("Q${r.no}", r.d, Color(0xFFFF9F0A)) {
                    store.updateRecord(rec.copy(res = rec.res.mapIndexed { k, q -> if (k == i) q.copy(d = !q.d) else q }))
                }
            }
        }

        Box(Modifier.padding(top = 24.dp))
        if (fresh) {
            PillButton("New session", Modifier.fillMaxWidth()) {
                vm.session = null
                vm.back()
                vm.setupHw = null
                vm.go(Screen.Setup)
            }
            PillButton(
                "Home", Modifier.fillMaxWidth().padding(top = 6.dp), bg = c.card, fg = c.ink,
                shadow = c.ink.copy(alpha = 0.1f), border = c.line
            ) { leave() }
        } else {
            if (!confirmDel) {
                PillButton("Delete this record", Modifier.fillMaxWidth(), bg = c.card, fg = c.bad, shadow = c.ink.copy(alpha = 0.1f), border = c.line, fontSp = 16) {
                    confirmDel = true
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Cancel", Modifier.weight(1f), bg = c.card, fg = c.ink, shadow = c.ink.copy(alpha = 0.1f), border = c.line, fontSp = 16) { confirmDel = false }
                    PillButton("Delete", Modifier.weight(1f), bg = c.bad, fg = Color.White, shadow = c.bad.copy(alpha = 0.4f), fontSp = 16) {
                        store.deleteRecord(rec.id)
                        vm.back()
                    }
                }
            }
        }
        Box(Modifier.padding(bottom = 30.dp))
    }
}
