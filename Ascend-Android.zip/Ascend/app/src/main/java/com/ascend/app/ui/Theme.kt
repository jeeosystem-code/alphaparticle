package com.ascend.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Same palette as the web app (:root and [data-theme=dark] CSS variables). */
data class AColors(
    val dark: Boolean,
    val bg: Color,
    val card: Color,
    val ink: Color,
    val muted: Color,
    val line: Color,
    val sand: Color,
    val sand2: Color,
    val glass: Color,
    val good: Color,
    val goodT: Color,
    val bad: Color,
    val btn: Color,
    val btnT: Color,
    val pause: Color
)

val LightColors = AColors(
    dark = false,
    bg = Color(0xFFF4ECDD),
    card = Color(0xFFFFFAF0),
    ink = Color(0xFF1B1A17),
    muted = Color(0xFF8A8272),
    line = Color(0xFFE4D9C3),
    sand = Color(0xFF0A84FF),
    sand2 = Color(0xFF7CC0FF),
    glass = Color(0xFF1B1A17),
    good = Color(0xFF3D7A4F),
    goodT = Color(0xFFFFFAF0),
    bad = Color(0xFFB85A3C),
    btn = Color(0xFF1B1A17),
    btnT = Color(0xFF7CC0FF),
    pause = Color(0xFF0A6CFF)
)

val DarkColors = AColors(
    dark = true,
    bg = Color(0xFF12110E),
    card = Color(0xFF1C1A15),
    ink = Color(0xFFF4ECDD),
    muted = Color(0xFF8F8672),
    line = Color(0xFF2C2920),
    sand = Color(0xFF0A84FF),
    sand2 = Color(0xFF7CC0FF),
    glass = Color(0xFFF4ECDD),
    good = Color(0xFF7FBF8E),
    goodT = Color(0xFF10200F),
    bad = Color(0xFFD98A6C),
    btn = Color(0xFF7CC0FF),
    btnT = Color(0xFF1B1A17),
    pause = Color(0xFF7CC0FF)
)

val LocalAColors = staticCompositionLocalOf { LightColors }

/** Shorthand used everywhere: A.ink, A.card ... */
object A {
    val c: AColors
        @Composable
        @ReadOnlyComposable
        get() = LocalAColors.current
}

@Composable
fun AscendTheme(dark: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalAColors provides (if (dark) DarkColors else LightColors)) {
        content()
    }
}

/** Subject colours, same order as HWCOL in the web app. */
val SubjectColors = listOf(
    Color(0xFFFF9F0A), Color(0xFF30C25B), Color(0xFFFF4D6D), Color(0xFF0A84FF),
    Color(0xFFA259F0), Color(0xFF1AB0C8), Color(0xFF5E5CE6), Color(0xFFFF6B3D)
)
