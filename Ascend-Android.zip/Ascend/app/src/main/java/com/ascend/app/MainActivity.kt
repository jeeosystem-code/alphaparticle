package com.ascend.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ascend.app.screens.FocusScreen
import com.ascend.app.screens.HistoryScreen
import com.ascend.app.screens.HomeScreen
import com.ascend.app.screens.HomeworkScreen
import com.ascend.app.screens.ResultScreen
import com.ascend.app.screens.SessionScreen
import com.ascend.app.screens.SettingsScreen
import com.ascend.app.screens.SetupScreen
import com.ascend.app.ui.A
import com.ascend.app.ui.AscendTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AscendApp() }
    }
}

@Composable
fun AscendApp() {
    val vm: AppVm = viewModel()
    val store = vm.store
    val sysDark = isSystemInDarkTheme()
    val dark = when (store.themeMode) {
        "dark" -> true
        "light" -> false
        else -> sysDark
    }
    val toggle = { store.setTheme(if (dark) "light" else "dark") }

    AscendTheme(dark) {
        val c = A.c
        val view = LocalView.current
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val ctl = WindowCompat.getInsetsController(w, view)
                ctl.isAppearanceLightStatusBars = !dark
                ctl.isAppearanceLightNavigationBars = !dark
            }
        }

        val cur = vm.current
        BackHandler(enabled = vm.stack.size > 1) {
            if (cur is Screen.Result) {
                vm.session = null
                vm.home()
            } else {
                vm.back()
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(c.bg)
                .systemBarsPadding()
                .imePadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            key(cur) {
                Column(
                    Modifier
                        .widthIn(max = 480.dp)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(start = 18.dp, end = 18.dp, top = 14.dp)
                ) {
                    when (cur) {
                        Screen.Home -> HomeScreen(vm, dark, toggle)
                        Screen.Setup -> SetupScreen(vm, dark, toggle)
                        Screen.Session -> SessionScreen(vm)
                        Screen.Result -> ResultScreen(vm, dark, toggle, vm.lastRecord?.id ?: "", true)
                        Screen.History -> HistoryScreen(vm, dark, toggle)
                        is Screen.HistoryView -> ResultScreen(vm, dark, toggle, cur.id, false)
                        Screen.Focus -> FocusScreen(vm, dark, toggle)
                        Screen.Homework -> HomeworkScreen(vm, dark, toggle)
                        Screen.Settings -> SettingsScreen(vm, dark, toggle)
                    }
                }
            }
        }
    }
}
