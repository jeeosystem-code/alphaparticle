package com.ascend.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Everything is saved on the device only, as small JSON files. */
class Store(private val ctx: Context) {
    val history = mutableStateListOf<SessionRec>()
    val subjects = mutableStateListOf<HwSubject>()
    val items = mutableStateListOf<HwItem>()
    var draft by mutableStateOf<Draft?>(null)

    private val prefs = ctx.getSharedPreferences("ascend", Context.MODE_PRIVATE)

    var themeMode by mutableStateOf(prefs.getString("theme", "system") ?: "system")
    var haptics by mutableStateOf(prefs.getBoolean("haptics", true))
    var lastPos by mutableStateOf(prefs.getFloat("pos", 4f).toDouble())
    var lastNeg by mutableStateOf(prefs.getFloat("neg", 1f).toDouble())
    var userName by mutableStateOf(prefs.getString("name", "") ?: "")

    var pmFocus by mutableStateOf(prefs.getInt("pmF", 25))
    var pmShort by mutableStateOf(prefs.getInt("pmS", 5))
    var pmLong by mutableStateOf(prefs.getInt("pmL", 15))
    var pmBlocks by mutableStateOf(prefs.getInt("pmN", 4))
    var pmAuto by mutableStateOf(prefs.getBoolean("pmAuto", true))
    var pmFocusTotalMin by mutableStateOf(prefs.getInt("pmTotal", 0))

    init {
        load()
    }

    fun setTheme(v: String) {
        themeMode = v
        prefs.edit().putString("theme", v).apply()
    }

    fun updateHaptics(v: Boolean) {
        haptics = v
        prefs.edit().putBoolean("haptics", v).apply()
    }

    fun setName(v: String) {
        userName = v.trim()
        prefs.edit().putString("name", userName).apply()
    }

    fun setMarks(p: Double, n: Double) {
        lastPos = p
        lastNeg = n
        prefs.edit().putFloat("pos", p.toFloat()).putFloat("neg", n.toFloat()).apply()
    }

    fun savePomo() {
        prefs.edit().putInt("pmF", pmFocus).putInt("pmS", pmShort).putInt("pmL", pmLong)
            .putInt("pmN", pmBlocks).putBoolean("pmAuto", pmAuto).apply()
    }

    fun addFocusMinutes(m: Int) {
        pmFocusTotalMin += m
        prefs.edit().putInt("pmTotal", pmFocusTotalMin).apply()
    }

    // ---------- history ----------
    fun addRecord(r: SessionRec) {
        history.add(0, r)
        saveHistory()
    }

    fun updateRecord(r: SessionRec) {
        val i = history.indexOfFirst { it.id == r.id }
        if (i >= 0) {
            history[i] = r
            saveHistory()
        }
    }

    fun deleteRecord(id: String) {
        history.removeAll { it.id == id }
        saveHistory()
    }

    // ---------- draft ----------
    fun putDraft(d: Draft?) {
        draft = d
        val f = File(ctx.filesDir, "draft.json")
        if (d == null) f.delete() else f.writeText(d.toJson().toString())
    }

    // ---------- homework ----------
    fun saveHw() {
        val s = JSONArray()
        subjects.forEach { s.put(it.toJson()) }
        val i = JSONArray()
        items.forEach { i.put(it.toJson()) }
        File(ctx.filesDir, "hw.json").writeText(JSONObject().put("subjects", s).put("items", i).toString())
    }

    fun addSubject(name: String, color: Int): HwSubject {
        val s = HwSubject(newId(), name.trim(), color)
        subjects.add(s)
        saveHw()
        return s
    }

    fun deleteSubject(id: String) {
        subjects.removeAll { it.id == id }
        items.removeAll { it.subjectId == id }
        saveHw()
    }

    fun putItem(item: HwItem) {
        val i = items.indexOfFirst { it.id == item.id }
        if (i >= 0) items[i] = item else items.add(item)
        saveHw()
    }

    fun deleteItem(id: String) {
        items.removeAll { it.id == id }
        saveHw()
    }

    // ---------- backup / restore ----------
    fun exportJson(): String {
        val h = JSONArray()
        history.forEach { h.put(it.toJson()) }
        val s = JSONArray()
        subjects.forEach { s.put(it.toJson()) }
        val i = JSONArray()
        items.forEach { i.put(it.toJson()) }
        return JSONObject().put("app", "ascend-android").put("version", 1)
            .put("history", h).put("subjects", s).put("items", i).toString(2)
    }

    /** Adds what is in the file; never removes anything already on the device. Returns how many records were added. */
    fun importJson(text: String): Int {
        val o = JSONObject(text)
        var added = 0
        val h = o.optJSONArray("history") ?: JSONArray()
        for (k in 0 until h.length()) {
            val r = SessionRec.fromJson(h.getJSONObject(k))
            if (history.none { it.id == r.id }) {
                history.add(r)
                added++
            }
        }
        history.sortByDescending { it.date }
        val s = o.optJSONArray("subjects") ?: JSONArray()
        for (k in 0 until s.length()) {
            val r = HwSubject.fromJson(s.getJSONObject(k))
            if (subjects.none { it.id == r.id }) {
                subjects.add(r)
                added++
            }
        }
        val it2 = o.optJSONArray("items") ?: JSONArray()
        for (k in 0 until it2.length()) {
            val r = HwItem.fromJson(it2.getJSONObject(k))
            if (items.none { it.id == r.id }) {
                items.add(r)
                added++
            }
        }
        saveHistory()
        saveHw()
        return added
    }

    private fun saveHistory() {
        val a = JSONArray()
        history.forEach { a.put(it.toJson()) }
        File(ctx.filesDir, "history.json").writeText(a.toString())
    }

    private fun load() {
        try {
            val f = File(ctx.filesDir, "history.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (k in 0 until a.length()) history.add(SessionRec.fromJson(a.getJSONObject(k)))
            }
        } catch (e: Exception) {
        }
        try {
            val f = File(ctx.filesDir, "hw.json")
            if (f.exists()) {
                val o = JSONObject(f.readText())
                val s = o.optJSONArray("subjects") ?: JSONArray()
                for (k in 0 until s.length()) subjects.add(HwSubject.fromJson(s.getJSONObject(k)))
                val i = o.optJSONArray("items") ?: JSONArray()
                for (k in 0 until i.length()) items.add(HwItem.fromJson(i.getJSONObject(k)))
            }
        } catch (e: Exception) {
        }
        try {
            val f = File(ctx.filesDir, "draft.json")
            if (f.exists()) draft = Draft.fromJson(JSONObject(f.readText()))
        } catch (e: Exception) {
        }
    }
}
