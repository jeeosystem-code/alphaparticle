package com.ascend.app

import android.app.Application
import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ascend.app.data.Draft
import com.ascend.app.data.HwItem
import com.ascend.app.data.QRes
import com.ascend.app.data.SessionRec
import com.ascend.app.data.Store
import com.ascend.app.data.newId
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object Setup : Screen()
    object Session : Screen()
    object Result : Screen()
    object History : Screen()
    class HistoryView(val id: String) : Screen()
    object Focus : Screen()
    object Homework : Screen()
    object Settings : Screen()
}

/** One practice session: same flow as the web app (start, mark Attempted / Not attempted, jump, finish). */
class SessionEngine(
    val name: String,
    val from: Int,
    val to: Int,
    val pos: Double,
    val neg: Double,
    val hw: String?,
    initial: List<QRes>? = null,
    startIdx: Int = 0
) {
    val res = mutableStateListOf<QRes>().apply {
        addAll(initial ?: (from..to).map { QRes(it) })
    }
    var idx by mutableIntStateOf(startIdx)
    var phase by mutableIntStateOf(0)          // 0 ready, 1 running, 2 done
    var paused by mutableStateOf(false)
    var now by mutableLongStateOf(System.currentTimeMillis())
    var stopArmedUntil by mutableLongStateOf(0L)

    private var base = 0L
    private var startAt = 0L
    private var pausedAt = 0L
    private var loadedAt = 0L

    val n: Int get() = res.size

    /** Elapsed time on the current question (re-reads `now`, so the UI updates every tick). */
    fun elapsed(): Long = base + (if (paused) pausedAt else now) - startAt

    private fun realElapsed(): Long = base + (if (paused) pausedAt else System.currentTimeMillis()) - startAt

    fun begin() {
        phase = 1
        beginQ()
    }

    private fun beginQ() {
        paused = false
        base = res[idx].t
        startAt = System.currentTimeMillis()
        now = startAt
        loadedAt = startAt
    }

    private fun commit() {
        if (phase != 1) return
        res[idx] = res[idx].copy(t = realElapsed())
    }

    fun togglePause() {
        if (phase != 1) return
        if (!paused) {
            pausedAt = System.currentTimeMillis()
            paused = true
        } else {
            startAt += System.currentTimeMillis() - pausedAt
            paused = false
        }
    }

    private fun nextOpen(from: Int): Int {
        for (k in 1 until n) {
            val j = (from + k) % n
            if (res[j].st == null) return j
        }
        return -1
    }

    /** Returns true when there is nothing left to answer. */
    fun answer(st: String): Boolean {
        if (phase != 1 || System.currentTimeMillis() - loadedAt < 350) return false
        commit()
        res[idx] = res[idx].copy(st = st, w = false)
        val nx = nextOpen(idx)
        if (nx < 0) return true
        idx = nx
        beginQ()
        return false
    }

    fun jump(j: Int) {
        if (phase != 1 || j == idx || j < 0 || j >= n) return
        commit()
        idx = j
        beginQ()
    }

    fun finish() {
        commit()
        phase = 2
    }

    fun toRecord() = SessionRec(newId(), name, System.currentTimeMillis(), from, to, pos, neg, res.toList(), hw)

    fun toDraft(): Draft {
        val l = res.toMutableList()
        if (phase == 1) l[idx] = l[idx].copy(t = realElapsed())
        return Draft(name, from, to, pos, neg, hw, l, idx)
    }

    val attempted: Int get() = res.count { it.st == "A" }
    val skipped: Int get() = res.count { it.st == "N" }
    val score: Double get() = res.count { it.st == "A" } * pos
    val max: Double get() = res.size * pos
}

/** Focus timer: focus / short break / long break, as in the web app. */
class PomodoroEngine(private val store: Store, private val onAlert: () -> Unit) {
    var phase by mutableStateOf("idle")   // idle, focus, short, long
    var running by mutableStateOf(false)
    var waiting by mutableStateOf(false)  // a block ended and auto-start is off
    var blocks by mutableIntStateOf(0)
    var sessionMinutes by mutableIntStateOf(0)
    var label by mutableStateOf("")
    var now by mutableLongStateOf(System.currentTimeMillis())

    private var endAt = 0L
    private var leftMs = 0L

    fun lenMs(ph: String): Long {
        val m = when (ph) {
            "focus" -> store.pmFocus
            "short" -> store.pmShort
            else -> store.pmLong
        }
        return m * 60000L
    }

    fun remaining(): Long = if (running) (endAt - now).coerceAtLeast(0L) else leftMs

    fun progress(): Float {
        val total = lenMs(phase)
        if (total <= 0L) return 0f
        return (1f - remaining().toFloat() / total).coerceIn(0f, 1f)
    }

    fun start() {
        blocks = 0
        sessionMinutes = 0
        begin("focus")
    }

    private fun begin(ph: String) {
        phase = ph
        leftMs = lenMs(ph)
        now = System.currentTimeMillis()
        endAt = now + leftMs
        running = true
        waiting = false
    }

    fun startNext() {
        if (waiting) begin(phase)
    }

    fun pauseResume() {
        if (phase == "idle" || waiting) return
        now = System.currentTimeMillis()
        if (running) {
            leftMs = (endAt - now).coerceAtLeast(0L)
            running = false
        } else {
            endAt = now + leftMs
            running = true
        }
    }

    fun skip() {
        if (phase == "idle") return
        end(false)
    }

    fun stop() {
        phase = "idle"
        running = false
        waiting = false
        blocks = 0
    }

    fun tick() {
        now = System.currentTimeMillis()
        if (running && now >= endAt) end(true)
    }

    private fun end(natural: Boolean) {
        val wasFocus = phase == "focus"
        if (wasFocus && natural) {
            blocks += 1
            sessionMinutes += store.pmFocus
            store.addFocusMinutes(store.pmFocus)
        } else if (wasFocus) {
            blocks += 1
        }
        val nxt = if (wasFocus) (if (blocks >= store.pmBlocks) "long" else "short") else "focus"
        if (phase == "long") blocks = 0
        if (natural) onAlert()
        if (store.pmAuto) {
            begin(nxt)
        } else {
            phase = nxt
            leftMs = lenMs(nxt)
            running = false
            waiting = true
        }
    }
}

class AppVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    val stack = mutableStateListOf<Screen>(Screen.Home)
    val current: Screen get() = stack.last()

    var session by mutableStateOf<SessionEngine?>(null)
    var lastRecord by mutableStateOf<SessionRec?>(null)
    var setupHw by mutableStateOf<HwItem?>(null)
    var openHwAdd by mutableStateOf(false)
    var toastMsg by mutableStateOf<String?>(null)

    val pomo = PomodoroEngine(store) { buzz(longArrayOf(0, 220, 110, 220, 110, 380)) }

    init {
        viewModelScope.launch {
            while (true) {
                delay(250)
                pomo.tick()
            }
        }
    }

    fun go(s: Screen) {
        stack.add(s)
    }

    fun back() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun home() {
        while (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun toast(m: String) {
        toastMsg = m
    }

    fun tick(ms: Long = 20) {
        if (!store.haptics) return
        buzzOnce(ms)
    }

    private fun vib(): Vibrator? =
        try {
            getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        } catch (e: Exception) {
            null
        }

    private fun buzzOnce(ms: Long) {
        try {
            vib()?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    fun buzz(pattern: LongArray) {
        if (!store.haptics) return
        try {
            vib()?.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (e: Exception) {
        }
    }

    // ---------- practice ----------
    fun startPractice(name: String, from: Int, to: Int, pos: Double, neg: Double, hw: String?) {
        store.setMarks(pos, neg)
        session = SessionEngine(name, from, to, pos, neg, hw)
        setupHw = null
        go(Screen.Session)
    }

    fun resumeDraft() {
        val d = store.draft ?: return
        if (d.res.isEmpty()) {
            store.putDraft(null)
            return
        }
        session = SessionEngine(d.name, d.from, d.to, d.pos, d.neg, d.hw, d.res, d.idx.coerceIn(0, d.res.size - 1))
        go(Screen.Session)
    }

    fun saveDraft() {
        val s = session ?: return
        if (s.phase == 1) store.putDraft(s.toDraft())
    }

    fun leaveSession(keep: Boolean) {
        if (keep) saveDraft() else if (session?.phase == 1) store.putDraft(null)
        session = null
        back()
    }

    fun finishSession() {
        val s = session ?: return
        s.finish()
        val rec = s.toRecord()
        store.addRecord(rec)
        store.putDraft(null)
        applyHomework(rec)
        lastRecord = rec
        buzz(longArrayOf(0, 60, 60, 120))
        if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
        stack.add(Screen.Result)
    }

    /** Same idea as hwAuto() in the web app: attempted questions are ticked off the linked homework. */
    private fun applyHomework(rec: SessionRec) {
        val id = rec.hw ?: return
        val item = store.items.firstOrNull { it.id == id } ?: return
        val got = rec.res.filter { it.st == "A" }.map { it.no }
        val merged = (item.attempted + got).distinct().sorted()
        val done = item.done || (item.hasRange && item.numbers.all { it in merged })
        store.putItem(item.copy(attempted = merged, done = done))
    }
}
